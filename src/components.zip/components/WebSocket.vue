<!-- <script setup>
import LoginPage from '@/pages/LoginPage.vue'
import { computed } from 'vue'
import { useStore } from 'vuex'

// const store = useStore()
// const connected = computed(() => store.state.connected)
</script>

<template>
  <LoginPage v-if="!connected" />
</template> -->
